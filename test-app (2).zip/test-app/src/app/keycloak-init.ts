import { KeycloakService } from 'keycloak-angular';
//import { environment } from './environments/environment';

export function initializer(keycloak: KeycloakService): () => Promise<any> {
    return (): Promise<any> => keycloak.init({
        config: {
            clientId: "test_client",
            realm: "master",
            url: "http://100.85.184.118:8080"
        },
        initOptions: {
            onLoad: 'login-required',
            enableLogging: true,
            silentCheckSsoRedirectUri: './assets/silent-check-sso.html',
            checkLoginIframe: false
        },
        enableBearerInterceptor: true,
        bearerPrefix: 'Bearer',
        bearerExcludedUrls: ['/assets']
    });
}